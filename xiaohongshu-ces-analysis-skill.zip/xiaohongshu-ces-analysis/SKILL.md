---
name: xiaohongshu-ces-analysis
description: Analyze Xiaohongshu/RED creator accounts using public profile notes and Xiaohongshu Creator Center data. Use when Codex needs to collect or interpret note performance, calculate CES (likes + saves + comments*4 + shares*4 + follows*4), compare CTR/CES, identify breakout notes, or summarize which covers, titles, copy, hashtags, topics, posting times, and note formats perform best for an account.
---

# Xiaohongshu CES Analysis

## Workflow

1. Confirm the browser is logged in to Xiaohongshu Creator Center before collecting Creator Center data. If not logged in, stop collection, keep/open the login page for the user, and resume only after login is complete.
2. Use Creator Center `内容分析` as the primary metrics source:
   `https://creator.xiaohongshu.com/statistics/data-analysis`
3. Use note detail pages to enrich high-value notes:
   `https://creator.xiaohongshu.com/statistics/note-detail?noteId=<note_id>`
4. Use the public profile as a fallback/enrichment source for public note links, note IDs, cover inspection, and public card text:
   `https://www.xiaohongshu.com/user/profile/<author_id>`
5. Preserve `note_id` for every row. It is the join key between public URLs and Creator Center URLs.
6. Calculate CES and compare notes by CES, CTR, exposure, watch/read count, follow conversion, and topic/title/cover patterns.
7. For breakout notes, inspect the note detail page and public note page to capture cover, title, copy structure, hashtags, source distribution, audience information, and diagnosis hints.

## Preferred Data Path

Prefer a structured export from Creator Center when available. If the user authorizes or asks for export-based analysis, click `导出数据`, then read the downloaded spreadsheet/CSV with the spreadsheets skill or a local parser.

When export is unavailable or the user wants an in-browser test, collect the visible `内容分析` table page by page. Safari Computer Use is acceptable for logged-in sessions; Chrome with the Codex Chrome Extension is preferred for larger repeatable crawls when available.

Do not publish, edit, delete, change permissions, comment, like, or submit forms. Reading pages, opening detail pages, changing analytics filters, paginating, and downloading exported analytics files are normal collection actions.

## Login Gate

Always run this gate before reading Creator Center metrics:

1. Open `https://creator.xiaohongshu.com/statistics/data-analysis`.
2. Check whether the page is logged in:
   - Logged in signals: account name/avatar, `内容分析`, `笔记数据`, `导出数据`, or the analytics table headers.
   - Logged out signals: `短信登录`, `登录即同意`, QR/phone login UI, or a redirect to a login page.
3. If logged out:
   - Tell the user that the selected browser is not logged in to Xiaohongshu Creator Center.
   - Keep the login page open as a handoff.
   - Ask the user to complete login in that browser.
   - After the user says login is done, reload or reopen `内容分析` and repeat the logged-in check.
4. Continue only after the analytics table or logged-in account area is visible.

Browser-specific notes:

- Chrome: first verify the Codex Chrome Extension works by listing/opening tabs. Chrome is preferred for repeatable batch collection, but the Creator Center login state is separate from Safari.
- Safari: use Computer Use when Safari already has the correct Xiaohongshu login state. It can be sufficient for manual tests and small batches.
- Public profile pages may be readable while Creator Center is logged out. Do not treat public profile access as proof that Creator Center metrics are available.

## Data Collection

For all-note analysis:

1. Pass the Login Gate.
2. Set topic/type/date filters only when the user requests a specific range. Otherwise leave filters broad and record any visible date/filter constraints.
3. Read the table columns exactly as shown. See `references/field-map.md`.
4. Paginate until no more pages are available, collecting every row.
5. For each row, extract `note_id`:
   - Open `详情数据` and read `noteId` from the URL, or
   - Match by title/time against the public profile URL path.
6. Use note detail pages for the top performers and a comparison set of average/low performers.
7. Use the public profile to inspect cover thumbnails and public presentation. If public and Creator Center numbers differ, keep both with clear source labels.

For a quick test:

1. Collect 10-20 rows from `内容分析`.
2. Compute CES.
3. Open 1-3 detail pages: one high CES, one high CTR/low CES, one low CTR/low CES.
4. Summarize whether the data path is stable before attempting all notes.

## Analysis

Read `references/analysis-method.md` before doing the actual performance analysis. Always include:

- Top notes by CES.
- Top notes by CTR.
- Notes with high CTR but weak CES.
- Notes with moderate CTR but strong CES.
- Clear breakout threshold used for this account.
- Patterns in cover, title, copy, hashtags, note type, posting date/time, and topic.
- Practical next-post recommendations with examples tailored to the account.

## Output Shape

Prefer a concise report with:

1. Data coverage and caveats.
2. Metric definitions and CES formula.
3. Breakout notes table with `note_id`, title, date, CTR, exposure, watch/read, likes, saves, comments, shares, follows, CES.
4. Findings grouped by cover, title, copy, topics/hashtags, publishing rhythm, and audience/source.
5. Recommendations for the next 5-10 notes.

When saving artifacts, include raw collected data, calculated data, and the final report separately.
