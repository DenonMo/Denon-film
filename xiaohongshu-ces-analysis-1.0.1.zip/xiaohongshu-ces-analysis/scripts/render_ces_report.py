#!/usr/bin/env python3
"""Render a Xiaohongshu CES CSV export as a standalone HTML report."""

from __future__ import annotations

import argparse
import csv
import html
import json
import math
import statistics
from pathlib import Path


ALIASES = {
    "note_id": ["note_id", "笔记ID", "笔记id", "ID", "id"],
    "title": ["title", "标题", "笔记标题", "笔记基础信息", "note_title"],
    "date": ["date", "发布日期", "发布时间", "publish_time", "publish_date"],
    "exposure": ["exposure", "曝光", "展示", "impressions"],
    "watch": ["watch", "观看", "阅读", "阅读量", "播放", "播放量", "views"],
    "ctr": ["ctr", "CTR", "封面点击率", "点击率", "cover_ctr"],
    "likes": ["likes", "点赞", "赞", "like"],
    "comments": ["comments", "评论", "comment"],
    "saves": ["saves", "收藏", "favorite", "favorites"],
    "follows": ["follows", "涨粉", "新增粉丝", "follow"],
    "shares": ["shares", "分享", "share"],
    "ces": ["CES", "ces"],
}


def pick(row: dict[str, str], key: str) -> str:
    normalized = {str(k).strip(): v for k, v in row.items()}
    for name in ALIASES[key]:
        if name in normalized:
            return str(normalized.get(name, "")).strip()
    return ""


def parse_number(value: str | int | float | None) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip().replace(",", "")
    if not text or text in {"-", "--", "—", "N/A", "nan", "None"}:
        return None
    multiplier = 1.0
    if text.endswith("%"):
        text = text[:-1]
    if text.endswith("万"):
        multiplier = 10000.0
        text = text[:-1]
    try:
        return float(text) * multiplier
    except ValueError:
        return None


def parse_ctr(value: str | int | float | None) -> float | None:
    parsed = parse_number(value)
    if parsed is None:
        return None
    return parsed / 100 if isinstance(value, str) and "%" in value else parsed


def fmt_int(value: float | None) -> str:
    if value is None or math.isnan(value):
        return "-"
    return f"{round(value):,}"


def fmt_float(value: float | None, digits: int = 1) -> str:
    if value is None or math.isnan(value):
        return "-"
    return f"{value:.{digits}f}"


def fmt_pct(value: float | None) -> str:
    if value is None or math.isnan(value):
        return "-"
    value = value * 100 if value <= 1 else value
    return f"{value:.1f}%"


def percentile(values: list[float], pct: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = (len(ordered) - 1) * pct
    lower = math.floor(index)
    upper = math.ceil(index)
    if lower == upper:
        return ordered[int(index)]
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (index - lower)


def safe(text: object) -> str:
    return html.escape(str(text))


def load_rows(path: Path) -> list[dict[str, str]]:
    if path.suffix.lower() == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            data = data.get("rows", [])
        return [dict(row) for row in data]

    with path.open("r", encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def enrich(rows: list[dict[str, str]]) -> list[dict[str, object]]:
    enriched = []
    for index, row in enumerate(rows, 1):
        values: dict[str, object] = {
            "note_id": pick(row, "note_id") or f"row-{index}",
            "title": pick(row, "title") or f"未命名笔记 {index}",
            "date": pick(row, "date"),
        }
        for key in ["exposure", "watch", "likes", "comments", "saves", "follows", "shares"]:
            values[key] = parse_number(pick(row, key)) or 0
        values["ctr"] = parse_ctr(pick(row, "ctr"))
        existing_ces = parse_number(pick(row, "ces"))
        values["ces"] = existing_ces if existing_ces is not None else (
            values["likes"]
            + values["saves"]
            + values["comments"] * 4
            + values["shares"] * 4
            + values["follows"] * 4
        )
        exposure = values["exposure"] or None
        watch = values["watch"] or None
        values["ces_per_1k_exposure"] = values["ces"] / exposure * 1000 if exposure else None
        values["ces_per_1k_watch"] = values["ces"] / watch * 1000 if watch else None
        values["save_rate"] = values["saves"] / watch if watch else None
        values["follow_rate"] = values["follows"] / watch if watch else None
        enriched.append(values)
    return enriched


def bar_chart(rows: list[dict[str, object]], key: str, label: str, max_items: int) -> str:
    top = sorted(rows, key=lambda row: float(row.get(key) or 0), reverse=True)[:max_items]
    maximum = max([float(row.get(key) or 0) for row in top] or [1])
    items = []
    for row in top:
        value = float(row.get(key) or 0)
        width = 4 if maximum == 0 else max(4, value / maximum * 100)
        display = fmt_pct(value) if key == "ctr" else fmt_int(value)
        items.append(
            f"""
            <div class="bar-row">
              <div class="bar-label" title="{safe(row['title'])}">{safe(row['title'])}</div>
              <div class="bar-track"><span style="width:{width:.1f}%"></span></div>
              <div class="bar-value">{display}</div>
            </div>
            """
        )
    return f"<section><h2>{safe(label)}</h2><div class=\"bars\">{''.join(items)}</div></section>"


def scatter(rows: list[dict[str, object]]) -> str:
    points = [row for row in rows if row.get("ctr") is not None and row.get("ces") is not None]
    if not points:
        return "<section><h2>CTR × CES 分布</h2><p class=\"empty\">缺少 CTR 或 CES，暂时无法绘制散点图。</p></section>"

    max_ctr = max(float(row["ctr"]) for row in points) or 1
    max_ces = max(float(row["ces"]) for row in points) or 1
    max_exposure = max(float(row.get("exposure") or 0) for row in points) or 1
    circles = []
    for row in points:
        x = 50 + float(row["ctr"]) / max_ctr * 660
        y = 360 - float(row["ces"]) / max_ces * 300
        radius = 4 + math.sqrt(float(row.get("exposure") or 0) / max_exposure) * 12
        circles.append(
            f"""
            <circle cx="{x:.1f}" cy="{y:.1f}" r="{radius:.1f}">
              <title>{safe(row['title'])} | CTR {fmt_pct(row['ctr'])} | CES {fmt_int(row['ces'])}</title>
            </circle>
            """
        )
    return f"""
    <section>
      <h2>CTR × CES 分布</h2>
      <svg class="scatter" viewBox="0 0 760 410" role="img" aria-label="CTR and CES scatter plot">
        <line x1="50" y1="360" x2="730" y2="360"></line>
        <line x1="50" y1="40" x2="50" y2="360"></line>
        <text x="690" y="392">CTR</text>
        <text x="12" y="48">CES</text>
        {''.join(circles)}
      </svg>
      <p class="hint">点越靠右，封面/标题点击越强；点越靠上，互动和转粉价值越强；点越大，曝光越高。</p>
    </section>
    """


def quadrant(rows: list[dict[str, object]]) -> str:
    ctrs = [float(row["ctr"]) for row in rows if row.get("ctr") is not None]
    ces_values = [float(row["ces"]) for row in rows if row.get("ces") is not None]
    if not ctrs or not ces_values:
        return ""
    ctr_cutoff = statistics.median(ctrs)
    ces_cutoff = statistics.median(ces_values)
    buckets = {
        "repeat": [],
        "promise_gap": [],
        "package": [],
        "weak": [],
    }
    for row in rows:
        ctr = row.get("ctr")
        ces = row.get("ces")
        if ctr is None or ces is None:
            continue
        if float(ctr) >= ctr_cutoff and float(ces) >= ces_cutoff:
            buckets["repeat"].append(row)
        elif float(ctr) >= ctr_cutoff and float(ces) < ces_cutoff:
            buckets["promise_gap"].append(row)
        elif float(ctr) < ctr_cutoff and float(ces) >= ces_cutoff:
            buckets["package"].append(row)
        else:
            buckets["weak"].append(row)

    labels = [
        ("repeat", "高 CTR + 高 CES", "优先复用：封面承诺和正文转化都较强。"),
        ("promise_gap", "高 CTR + 低 CES", "重点复盘：点击进来了，但内容承接或人群匹配不足。"),
        ("package", "低/中 CTR + 高 CES", "值得重包：内容有价值，封面标题可以继续测试。"),
        ("weak", "低 CTR + 低 CES", "谨慎延展：除非有战略价值，否则降低投入。"),
    ]
    cards = []
    for key, title, note in labels:
        examples = sorted(buckets[key], key=lambda row: float(row.get("ces") or 0), reverse=True)[:3]
        lis = "".join(f"<li>{safe(row['title'])}</li>" for row in examples) or "<li>暂无</li>"
        cards.append(f"<div class=\"quadrant\"><h3>{safe(title)}</h3><p>{safe(note)}</p><ul>{lis}</ul></div>")
    return f"<section><h2>机会象限</h2><div class=\"quadrants\">{''.join(cards)}</div></section>"


def date_range(rows: list[dict[str, object]]) -> str:
    dates = [str(row.get("date") or "")[:10] for row in rows if row.get("date")]
    dates = [date for date in dates if date]
    if not dates:
        return "未记录日期范围"
    return f"{min(dates)} 至 {max(dates)}"


def coverage_section(rows: list[dict[str, object]], coverage_label: str, coverage_note: str) -> str:
    return f"""
    <section class="coverage">
      <div>
        <span class="eyebrow">数据覆盖说明</span>
        <h2>{safe(coverage_label)}</h2>
        <p>{safe(coverage_note)}</p>
      </div>
      <div class="coverage-facts">
        <div><span>采集笔记数</span><strong>{fmt_int(len(rows))}</strong></div>
        <div><span>发布时间范围</span><strong>{safe(date_range(rows))}</strong></div>
      </div>
    </section>
    """


def pattern_groups(rows: list[dict[str, object]]) -> list[tuple[str, list[dict[str, object]]]]:
    groups = [
        ("旅行/地点叙事", ["大连", "济州", "首尔", "清州", "徒步", "沙巴", "立山", "山", "海", "岛", "树", "冰城"]),
        ("季节/自然氛围", ["夏天", "春天", "绿色", "新绿", "落日", "雪", "水波", "海面", "光"]),
        ("胶片/摄影过程", ["胶片", "摄影", "镜头", "REDSkill", "流程", "书签"]),
        ("事件/社群身份", ["地铁", "影展", "社长", "工区", "moments"]),
    ]
    result = []
    for label, keywords in groups:
        matched = [row for row in rows if any(keyword in str(row.get("title") or "") for keyword in keywords)]
        if matched:
            result.append((label, matched))
    return result


def avg(values: list[float]) -> float | None:
    return statistics.mean(values) if values else None


def examples(rows: list[dict[str, object]], limit: int = 3) -> str:
    chosen = sorted(rows, key=lambda row: float(row.get("ces") or 0), reverse=True)[:limit]
    return "".join(f"<li>{safe(row['title'])}</li>" for row in chosen)


def strategy_insights(rows: list[dict[str, object]]) -> str:
    ctr_rows = [row for row in rows if row.get("ctr") is not None]
    ces_values = [float(row.get("ces") or 0) for row in rows]
    ctr_values = [float(row.get("ctr") or 0) for row in ctr_rows]
    ces_p90 = percentile(ces_values, 0.9) or 0
    ctr_p75 = percentile(ctr_values, 0.75) or 0
    high_ces = [row for row in rows if float(row.get("ces") or 0) >= ces_p90]
    high_ctr = [row for row in ctr_rows if float(row.get("ctr") or 0) >= ctr_p75]

    pattern_cards = []
    for label, matched in pattern_groups(rows):
        avg_ces = avg([float(row.get("ces") or 0) for row in matched])
        avg_ctr = avg([float(row.get("ctr") or 0) for row in matched if row.get("ctr") is not None])
        pattern_cards.append(
            f"""
            <div class="pattern-card">
              <h3>{safe(label)}</h3>
              <p>{len(matched)} 条 · 平均 CES {fmt_int(avg_ces)} · 平均 CTR {fmt_pct(avg_ctr)}</p>
              <ul>{examples(matched)}</ul>
            </div>
            """
        )

    return f"""
    <section class="strategy">
      <span class="eyebrow">内容策略分析</span>
      <h2>什么内容更容易拿到高 CTR 和高 CES</h2>
      <p class="account-summary">一句话总结：这个账号的核心风格是 <strong>胶片质感的城市/旅行/季节叙事账号</strong>，优势在于把具体地点、季节情绪和一张有记忆点的画面包装成可点击的故事入口。</p>
      <div class="strategy-grid">
        <div class="strategy-card">
          <h3>高 CTR 内容特征</h3>
          <p>高 CTR 更常出现在标题里带有地点、行动成本或画面悬念的笔记。它们让用户在点开前就能想象“我会看到什么”。</p>
          <ul>{examples(high_ctr)}</ul>
        </div>
        <div class="strategy-card">
          <h3>高 CES 内容特征</h3>
          <p>高 CES 笔记通常不只好看，还能提供故事、情绪或收藏价值。地点叙事和季节氛围叠加时，更容易带来点赞、收藏、评论和分享。</p>
          <ul>{examples(high_ces)}</ul>
        </div>
      </div>
      <div class="patterns">{''.join(pattern_cards)}</div>
      <div class="recommendations">
        <div>
          <h3>封面建议</h3>
          <p>优先使用一眼能读懂的强场景：城市地标、人物尺度、季节色块、明确主体。封面文字控制在 6-10 个字，突出地点或情绪，例如“夏天开始”“为了这个镜头”。</p>
        </div>
        <div>
          <h3>标题/文案建议</h3>
          <p>用“地点 + 行动/代价 + 画面结果”的结构：为了这个镜头去了___、在___记录了谁的人生、徒步__km看见___。正文开头先交代为什么值得看，再补拍摄过程和情绪。</p>
        </div>
        <div>
          <h3>话题建议</h3>
          <p>围绕胶片摄影、城市漫游、季节影像、旅行记录、摄影路线、拍摄机位、地方生活感来组合。每篇选 1 个主话题，不要让标签分散内容定位。</p>
        </div>
        <div>
          <h3>下一步复用方向</h3>
          <p>复用“大连/首尔/清州/夏天/一棵树/一个镜头”这类已验证意象。对高曝光低 CTR 的内容，优先重做封面标题，而不是简单判定题材无效。</p>
        </div>
      </div>
    </section>
    """


def table(rows: list[dict[str, object]], max_items: int) -> str:
    top = sorted(rows, key=lambda row: float(row.get("ces") or 0), reverse=True)[:max_items]
    body = []
    for row in top:
        body.append(
            f"""
            <tr>
              <td>{safe(row['title'])}<span>{safe(row.get('note_id', ''))}</span></td>
              <td>{safe(row.get('date', ''))}</td>
              <td>{fmt_int(row.get('exposure'))}</td>
              <td>{fmt_int(row.get('watch'))}</td>
              <td>{fmt_pct(row.get('ctr'))}</td>
              <td>{fmt_int(row.get('likes'))}</td>
              <td>{fmt_int(row.get('saves'))}</td>
              <td>{fmt_int(row.get('comments'))}</td>
              <td>{fmt_int(row.get('shares'))}</td>
              <td>{fmt_int(row.get('follows'))}</td>
              <td><strong>{fmt_int(row.get('ces'))}</strong></td>
            </tr>
            """
        )
    return f"""
    <section>
      <h2>CES 排行明细</h2>
      <div class="table-wrap">
        <table>
          <thead><tr><th>笔记</th><th>日期</th><th>曝光</th><th>观看</th><th>CTR</th><th>赞</th><th>藏</th><th>评</th><th>分享</th><th>涨粉</th><th>CES</th></tr></thead>
          <tbody>{''.join(body)}</tbody>
        </table>
      </div>
    </section>
    """


def load_profile(path: Path | None) -> dict[str, object]:
    if not path:
        return {}
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise SystemExit("Profile JSON must be an object.")
    return data


def metric_chip(label: str, value: object) -> str:
    if value in {None, ""}:
        return ""
    return f"<div class=\"profile-chip\"><span>{safe(label)}</span><strong>{safe(value)}</strong></div>"


def profile_header(profile: dict[str, object], title: str, source_label: str, top_title: str, card_html: str, coverage_label: str) -> str:
    name = str(profile.get("display_name") or profile.get("name") or "小红书账号")
    handle = str(profile.get("handle") or profile.get("xiaohongshu_id") or "")
    bio = str(profile.get("bio") or "基于小红书创作者中心数据生成的内容表现分析。")
    location = str(profile.get("location") or "")
    role = str(profile.get("role") or "")
    avatar = str(profile.get("avatar") or profile.get("avatar_url") or "")
    avatar_html = ""
    if avatar.startswith(("http://", "https://", "file://", "data:")):
        avatar_html = f"<img class=\"avatar\" src=\"{safe(avatar)}\" alt=\"{safe(name)} 头像\">"
    tags = [item for item in [location, role] if item]
    tag_html = "".join(f"<span>{safe(item)}</span>" for item in tags)
    chips = "".join(
        [
            metric_chip("关注", profile.get("following")),
            metric_chip("粉丝", profile.get("followers")),
            metric_chip("获赞与收藏", profile.get("likes_and_saves")),
        ]
    )
    handle_html = f"<span class=\"handle\">小红书号：{safe(handle)}</span>" if handle else ""
    return f"""
  <header class="hero">
    <div class="hero-art" aria-hidden="true">
      <span></span><span></span><span></span><span></span>
    </div>
    <div class="hero-inner">
      <div class="brand-row">
        <div class="red-badge">RED DATA</div>
        <p>{safe(source_label)}</p>
      </div>
      <div class="hero-grid">
        <div>
          <h1>{safe(title)}</h1>
          <p class="hero-lead">当前样本中，CES 最高的是 <strong>{top_title}</strong>。这份报告用于区分封面标题带来的点击、正文内容带来的深度互动，以及值得重包复用的内容机会。</p>
          <p class="mode-pill">{safe(coverage_label)}</p>
          <p class="formula">CES = 点赞 + 收藏 + 评论*4 + 分享*4 + 涨粉*4</p>
        </div>
        <aside class="profile-card {'has-avatar' if avatar_html else 'no-avatar'}">
          {avatar_html}
          <div class="profile-main">
            <h2>{safe(name)}</h2>
            {handle_html}
            <p>{safe(bio)}</p>
            <div class="profile-tags">{tag_html}</div>
          </div>
          <div class="profile-chips">{chips}</div>
        </aside>
      </div>
      <div class="kpis">{card_html}</div>
    </div>
  </header>
    """


def render(
    rows: list[dict[str, object]],
    title: str,
    source_label: str,
    top_n: int,
    profile: dict[str, object] | None = None,
    coverage_label: str = "默认简单模式采集",
    coverage_note: str = "当前数据来自创作者中心默认视图/当前采集范围，不等同于账号历史全部笔记。若需要全量结论，应使用导出数据或逐页采集全部分页后再分析。",
) -> str:
    ces_values = [float(row.get("ces") or 0) for row in rows]
    ctr_values = [float(row["ctr"]) for row in rows if row.get("ctr") is not None]
    top_ces = max(rows, key=lambda row: float(row.get("ces") or 0)) if rows else None
    cards = [
        ("采集笔记数", fmt_int(len(rows))),
        ("总曝光", fmt_int(sum(float(row.get("exposure") or 0) for row in rows))),
        ("总观看", fmt_int(sum(float(row.get("watch") or 0) for row in rows))),
        ("CES 中位数", fmt_int(statistics.median(ces_values) if ces_values else None)),
        ("CES P90", fmt_int(percentile(ces_values, 0.9))),
        ("CTR 中位数", fmt_pct(statistics.median(ctr_values) if ctr_values else None)),
    ]
    card_html = "".join(f"<div class=\"kpi\"><span>{safe(label)}</span><strong>{safe(value)}</strong></div>" for label, value in cards)
    top_title = safe(top_ces["title"]) if top_ces else "-"
    header_html = profile_header(profile or {}, title, source_label, top_title, card_html, coverage_label)

    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{safe(title)}</title>
  <style>
    :root {{
      --red:#ff2442; --deep-red:#b80f2f; --soft-red:#fff0f3; --ink:#241115;
      --muted:#7b6268; --line:#f1ccd3; --bg:#fff6f7; --panel:#ffffff;
      --gold:#ffb23e; --rose:#ef476f; --blue:#6a5cff;
    }}
    * {{ box-sizing:border-box; }}
    body {{
      margin:0; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
      color:var(--ink); background:
        radial-gradient(circle at 10% 0%, rgba(255,36,66,.18), transparent 28%),
        linear-gradient(180deg,#fff7f8 0%,#fffafb 42%,#ffffff 100%);
    }}
    main {{ padding:24px 40px 52px; max-width:1180px; margin:0 auto; }}
    h1 {{ margin:0 0 14px; font-size:40px; line-height:1.12; font-weight:820; letter-spacing:0; max-width:680px; }}
    h2 {{ margin:0 0 16px; font-size:20px; }}
    h3 {{ margin:0 0 8px; font-size:16px; }}
    p {{ color:var(--muted); line-height:1.6; }}
    section {{ margin-top:22px; padding:24px; background:rgba(255,255,255,.94); border:1px solid var(--line); border-radius:8px; box-shadow:0 14px 34px rgba(184,15,47,.06); }}
    .hero {{ position:relative; overflow:hidden; background:linear-gradient(135deg,#ff2442 0%,#ff5a6e 48%,#ff8a70 100%); color:#fff; }}
    .hero::after {{ content:""; position:absolute; inset:auto 0 0 0; height:70px; background:linear-gradient(180deg,rgba(255,246,247,0),var(--bg)); }}
    .hero-inner {{ position:relative; z-index:1; max-width:1180px; margin:0 auto; padding:34px 40px 44px; }}
    .hero-art span {{ position:absolute; border:1px solid rgba(255,255,255,.32); border-radius:999px; }}
    .hero-art span:nth-child(1) {{ width:260px; height:260px; right:8%; top:-90px; }}
    .hero-art span:nth-child(2) {{ width:180px; height:180px; right:24%; bottom:20px; }}
    .hero-art span:nth-child(3) {{ width:110px; height:110px; left:6%; top:48px; }}
    .hero-art span:nth-child(4) {{ width:420px; height:420px; left:-180px; bottom:-230px; }}
    .brand-row {{ display:flex; align-items:center; gap:12px; margin-bottom:26px; }}
    .brand-row p {{ margin:0; color:rgba(255,255,255,.82); }}
    .red-badge {{ width:max-content; padding:8px 12px; border-radius:999px; color:var(--red); background:#fff; font-size:12px; font-weight:800; letter-spacing:.04em; }}
    .hero-grid {{ display:grid; grid-template-columns:minmax(0,1fr) 360px; gap:28px; align-items:stretch; }}
    .hero-lead {{ max-width:720px; margin:0; color:rgba(255,255,255,.9); font-size:16px; }}
    .hero-lead strong {{ color:#fff; }}
    .mode-pill {{ display:inline-block; margin:18px 10px 0 0; padding:9px 12px; border-radius:999px; color:#fff; background:rgba(255,255,255,.2); border:1px solid rgba(255,255,255,.32); font-size:13px; }}
    .formula {{ display:inline-block; margin:20px 0 0; padding:10px 13px; border:1px solid rgba(255,255,255,.35); border-radius:8px; color:#fff; background:rgba(255,255,255,.14); }}
    .profile-card {{ display:grid; gap:16px; align-content:start; padding:18px; border:1px solid rgba(255,255,255,.28); border-radius:8px; background:rgba(255,255,255,.18); }}
    .profile-card.has-avatar {{ grid-template-columns:74px 1fr; }}
    .profile-card.no-avatar {{ grid-template-columns:1fr; }}
    .avatar {{ display:block; width:74px; height:74px; border-radius:50%; object-fit:cover; background:#fff; box-shadow:0 16px 28px rgba(85,0,18,.18); }}
    .profile-main h2 {{ margin:0 0 4px; color:#fff; font-size:24px; }}
    .handle {{ display:block; color:rgba(255,255,255,.82); font-size:13px; margin-bottom:8px; }}
    .profile-main p {{ margin:0; color:rgba(255,255,255,.9); font-size:13px; }}
    .profile-tags {{ display:flex; gap:8px; flex-wrap:wrap; margin-top:10px; }}
    .profile-tags span {{ padding:5px 8px; border-radius:999px; background:rgba(255,255,255,.2); color:#fff; font-size:12px; }}
    .profile-chips {{ grid-column:1 / -1; display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:8px; }}
    .profile-chip {{ padding:10px; border-radius:8px; background:rgba(255,255,255,.2); }}
    .profile-chip span {{ display:block; color:rgba(255,255,255,.76); font-size:12px; margin-bottom:4px; }}
    .profile-chip strong {{ color:#fff; font-size:18px; }}
    .kpis {{ display:grid; grid-template-columns:repeat(6,minmax(0,1fr)); gap:12px; margin-top:22px; }}
    .kpi {{ border:1px solid rgba(255,255,255,.26); border-radius:8px; padding:14px; background:rgba(255,255,255,.93); box-shadow:0 12px 24px rgba(111,0,20,.08); }}
    .kpi span {{ display:block; color:#8f5963; font-size:13px; margin-bottom:8px; }}
    .kpi strong {{ font-size:22px; color:var(--deep-red); }}
    .bars {{ display:grid; gap:11px; }}
    .bar-row {{ display:grid; grid-template-columns:minmax(180px,1.1fr) minmax(180px,2fr) 86px; gap:12px; align-items:center; }}
    .bar-label {{ white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }}
    .bar-track {{ height:12px; border-radius:999px; background:#ffe5e9; overflow:hidden; }}
    .bar-track span {{ display:block; height:100%; background:linear-gradient(90deg,var(--red),var(--gold)); }}
    .bar-value {{ text-align:right; font-variant-numeric:tabular-nums; }}
    .scatter {{ width:100%; height:auto; border:1px solid var(--line); border-radius:8px; background:linear-gradient(180deg,#fff,#fff8f9); }}
    .scatter line {{ stroke:#dca5ae; stroke-width:1; }}
    .scatter text {{ fill:var(--muted); font-size:14px; }}
    .scatter circle {{ fill:var(--red); fill-opacity:.58; stroke:var(--deep-red); stroke-width:1; }}
    .hint {{ margin-bottom:0; font-size:14px; }}
    .eyebrow {{ display:inline-block; margin-bottom:8px; color:var(--red); font-size:12px; font-weight:800; letter-spacing:.06em; }}
    .coverage {{ display:grid; grid-template-columns:minmax(0,1.4fr) minmax(280px,.8fr); gap:18px; align-items:center; border-color:#ffc7d1; background:linear-gradient(135deg,#fff,#fff1f4); }}
    .coverage p {{ margin:0; }}
    .coverage-facts {{ display:grid; grid-template-columns:1fr; gap:10px; }}
    .coverage-facts div {{ padding:14px; border:1px solid var(--line); border-radius:8px; background:#fff; }}
    .coverage-facts span {{ display:block; color:var(--muted); font-size:13px; margin-bottom:5px; }}
    .coverage-facts strong {{ color:var(--deep-red); font-size:18px; }}
    .quadrants {{ display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:12px; }}
    .quadrant {{ border:1px solid var(--line); border-radius:8px; padding:14px; min-height:180px; background:linear-gradient(180deg,#fff,#fff8f9); }}
    .quadrant h3 {{ color:var(--deep-red); }}
    .quadrant p {{ margin:0 0 10px; font-size:13px; }}
    .quadrant ul {{ margin:0; padding-left:18px; color:var(--ink); }}
    .quadrant li {{ margin:6px 0; }}
    .strategy .account-summary {{ margin-top:0; font-size:16px; }}
    .strategy-grid {{ display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:12px; margin-top:16px; }}
    .strategy-card,.pattern-card,.recommendations div {{ padding:16px; border:1px solid var(--line); border-radius:8px; background:linear-gradient(180deg,#fff,#fff8f9); }}
    .strategy-card h3,.pattern-card h3,.recommendations h3 {{ color:var(--deep-red); }}
    .strategy-card ul,.pattern-card ul {{ margin:10px 0 0; padding-left:18px; }}
    .patterns {{ display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:12px; margin-top:12px; }}
    .pattern-card p {{ margin:0; font-size:13px; }}
    .recommendations {{ display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:12px; margin-top:12px; }}
    .recommendations p {{ margin:0; font-size:13px; }}
    .table-wrap {{ overflow:auto; }}
    table {{ width:100%; border-collapse:collapse; min-width:980px; }}
    th,td {{ border-bottom:1px solid var(--line); padding:10px 8px; text-align:right; vertical-align:top; }}
    th {{ color:#7f2434; background:#fff6f7; }}
    th:first-child,td:first-child {{ text-align:left; min-width:260px; }}
    td span {{ display:block; color:var(--muted); font-size:12px; margin-top:4px; }}
    td strong {{ color:var(--deep-red); }}
    .empty {{ margin:0; }}
    @media (max-width:900px) {{
      .hero-inner, main {{ padding-left:18px; padding-right:18px; }}
      h1 {{ font-size:30px; }}
      .hero-grid {{ grid-template-columns:1fr; }}
      .kpis {{ grid-template-columns:repeat(2,minmax(0,1fr)); }}
      .profile-chips {{ grid-template-columns:1fr; }}
      .coverage,.strategy-grid,.patterns,.recommendations {{ grid-template-columns:1fr; }}
      .bar-row {{ grid-template-columns:1fr; gap:6px; }}
      .bar-value {{ text-align:left; }}
      .quadrants {{ grid-template-columns:1fr; }}
    }}
  </style>
</head>
<body>
  {header_html}
  <main>
    {coverage_section(rows, coverage_label, coverage_note)}
    {scatter(rows)}
    {bar_chart(rows, "ces", "Top CES 笔记", top_n)}
    {bar_chart([row for row in rows if row.get("ctr") is not None], "ctr", "Top CTR 笔记", top_n)}
    {quadrant(rows)}
    {strategy_insights(rows)}
    {table(rows, top_n)}
  </main>
</body>
</html>
"""


def main() -> None:
    parser = argparse.ArgumentParser(description="Render Xiaohongshu CES visual report from CSV or JSON.")
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", "-o", type=Path, default=Path("ces_report.html"))
    parser.add_argument("--title", default="小红书内容表现可视化报告")
    parser.add_argument("--source-label", default="小红书创作者中心")
    parser.add_argument("--top-n", type=int, default=12)
    parser.add_argument("--profile-json", type=Path, help="Optional account profile JSON for the report hero.")
    parser.add_argument("--coverage-label", default="默认简单模式采集")
    parser.add_argument(
        "--coverage-note",
        default="当前数据来自创作者中心默认视图/当前采集范围，不等同于账号历史全部笔记。若需要全量结论，应使用导出数据或逐页采集全部分页后再分析。",
    )
    args = parser.parse_args()

    rows = enrich(load_rows(args.input))
    if not rows:
        raise SystemExit("No rows found in input file.")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        render(
            rows,
            args.title,
            args.source_label,
            args.top_n,
            load_profile(args.profile_json),
            args.coverage_label,
            args.coverage_note,
        ),
        encoding="utf-8",
    )
    print(f"Wrote {args.output}")


if __name__ == "__main__":
    main()
