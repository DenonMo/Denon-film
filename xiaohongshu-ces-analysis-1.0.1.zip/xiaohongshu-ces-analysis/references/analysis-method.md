# Analysis Method

## Core Metrics

Use the user's CES formula:

```text
CES = likes + saves + comments * 4 + shares * 4 + follows * 4
```

Use Creator Center field names:

- `likes` = `点赞`
- `saves` = `收藏`
- `comments` = `评论`
- `shares` = `分享`
- `follows` = `涨粉`
- `CTR` = `封面点击率`
- `exposure` = `曝光`
- `watch/read` = `观看`

Treat missing values (`-`) as unknown. For provisional CES, use zero only after explicitly labeling it as an assumption.

## Breakout Definition

Define breakout notes relative to the account, not by a universal number.

Recommended approach:

1. Compute CES for all collected notes.
2. Use p90/p95, median, mean, and standard deviation to understand distribution.
3. Mark a note as breakout if it is clearly separated from the cluster, for example:
   - CES >= p90 and at least 2x median, or
   - CES >= mean + 2 standard deviations, or
   - a visible outlier in a sorted CES table.
4. If the distribution has one extreme viral note, analyze it separately so it does not hide mid-tier patterns.

## Comparisons to Run

Always compare:

- High CTR + high CES: strong cover and content match.
- High CTR + low CES: cover/title attracts clicks but content or audience fit may not convert.
- Low/moderate CTR + high CES: topic/content resonates after entry; cover/title may be under-optimized.
- High exposure + low CTR: distribution opportunity wasted by cover/title.
- Low exposure + high CES rate: content may deserve repackaging.

Derived metrics that help:

```text
watch_rate = watch / exposure
like_rate = likes / watch
save_rate = saves / watch
comment_rate = comments / watch
share_rate = shares / watch
follow_rate = follows / watch
ces_per_1k_exposure = CES / exposure * 1000
ces_per_1k_watch = CES / watch * 1000
```

Use ratios only when denominators are present and large enough to be meaningful.

## Content Feature Coding

Code each note manually or semi-automatically into simple features:

- Cover: photo/video, text overlay, face/person, landscape, object/detail, color tone, contrast, composition, curiosity gap.
- Title: emoji use, location, number/time hook, question, emotional word, concrete object, series marker, short poetic title, benefit/promise.
- Copy: story, technical/photo process, travel diary, product/object, event/community, call to comment, hashtag density.
- Topics: location, film photography, photography technique, seasonal, exhibition/event, lifestyle, community role.
- Format: image, video, duration if visible.
- Timing: publish date, weekday, hour, recency.

For subjective cover analysis, inspect the cover image directly and state that it is a visual judgment.

## Reporting

Ground every conclusion in examples. Prefer:

- "The top CES notes tend to..." plus 2-4 note examples.
- "Low CES notes often..." plus counterexamples.
- "CTR seems to matter when..." with evidence.

Avoid claiming causation from small samples. Use language like "associated with", "appears to", and "worth testing next".
