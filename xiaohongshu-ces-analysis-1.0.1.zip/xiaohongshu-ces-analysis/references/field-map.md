# Field Map

## IDs and URLs

- Author profile URL: `https://www.xiaohongshu.com/user/profile/<author_id>`
- Public note URL examples:
  - `https://www.xiaohongshu.com/explore/<note_id>?...`
  - `https://www.xiaohongshu.com/user/profile/<author_id>/<note_id>?...`
- Creator detail URL: `https://creator.xiaohongshu.com/statistics/note-detail?noteId=<note_id>`
- Always preserve `note_id`; it is the durable join key.

## Creator Center `内容分析`

Observed path: `https://creator.xiaohongshu.com/statistics/data-analysis`

Logged-out signals observed in Chrome:

- `短信登录`
- `登录即同意`
- Phone/SMS/QR login UI

These signals mean Creator Center metrics are unavailable in that browser until the user logs in. Public Xiaohongshu profile access does not imply Creator Center login.

Logged-in signals observed in Safari:

- Account display such as `Denon Film`
- Left navigation including `笔记管理`, `数据看板`, `内容分析`, `粉丝数据`
- `笔记数据` tab
- `导出数据`
- Analytics table headers listed below

Observed table columns:

1. `笔记基础信息`: title and publish time
2. `曝光`
3. `观看`
4. `封面点击率`
5. `点赞`
6. `评论`
7. `收藏`
8. `涨粉`
9. `分享`
10. `人均观看时长`
11. `弹幕`
12. `操作`: includes `详情数据`

Use `-` as missing/null, not zero, unless the user asks to coerce missing values.

## Creator Center `笔记管理`

Observed path: `https://creator.xiaohongshu.com/new/note-manager`

The list shows title, publish time, cover, and five icon metrics:

1. Eye icon: view/watch count
2. Comment bubble: comments
3. Heart: likes
4. Star: saves/favorites
5. Arrow: shares

This page is useful for quick visual inspection and all-note count, but `内容分析` is the better metric source because it includes exposure, CTR, follows, and watch duration.

## Creator Detail

Observed path: `https://creator.xiaohongshu.com/statistics/note-detail?noteId=<note_id>`

Useful detail tabs:

- `笔记诊断`: cover CTR peer comparison, follow count peer comparison, content richness, diagnosis hints.
- `核心数据`: exposure, watch/read count, cover CTR, average watch duration, follow count, follower/non-follower splits, hourly/daily trend.
- `观看来源`: source mix such as home recommendation, personal homepage, follow page, other.
- `观众画像`: audience distribution.

The top detail area includes cover, title, hashtags/topics, publish time, and `note_id` in the URL.

## Public Profile

The public profile can expose account metadata, public note cards, note links, note IDs, titles, covers, and public like/save display counts. It does not expose Creator Center-only metrics such as exposure, CTR, follow conversion, and source/audience breakdowns.
