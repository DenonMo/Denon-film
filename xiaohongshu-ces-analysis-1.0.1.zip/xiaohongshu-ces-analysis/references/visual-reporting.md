# Visual Reporting

Use this reference when the user asks for a report, dashboard, visualization, client-facing output, or anything beyond a quick text summary.

## Default Deliverables

When enough structured note metrics are available, save these artifacts:

1. Raw data table, unchanged from collection/export.
2. Calculated data table with `CES`, derived rates, segment labels, and notes.
3. Visual HTML report generated with `scripts/render_ces_report.py` when the data is CSV-compatible.
4. Short written summary in the chat that links to the report and names the strongest findings.
5. Coverage label that distinguishes default/simple-mode samples, date-range samples, selected-range exports, and all-note exports.

If HTML generation is not possible, still include the same sections in Markdown tables and describe the missing input or dependency.

## Visual Report Structure

Use a decision-oriented layout:

1. Coverage strip: date range, note count, data source, missing-field caveats.
2. Red-themed account hero: account display name, Xiaohongshu ID, bio, follower count, likes+saves count, account tags, data source, CES formula, and top CES note.
3. KPI cards: total exposure, total watch/read, median CES, p90 CES, median CTR, top CES note.
4. Performance landscape: CTR vs CES scatter plot with exposure as point size.
5. Top performer bars: top notes by CES and top notes by CTR.
6. Opportunity quadrants:
   - High CTR + high CES: repeatable winners.
   - High CTR + low CES: click promise does not convert.
   - Low/moderate CTR + high CES: content is strong but packaging needs testing.
   - High exposure + low CTR: distribution chance not captured.
7. Breakout table: title, date, note ID, exposure, watch/read, CTR, likes, saves, comments, shares, follows, CES.
8. Pattern findings: cover, title, copy, topic/hashtag, format, timing, source/audience.
9. Next-post plan: 5-10 concrete topics or packaging tests.

Always distinguish collection modes:

- `默认简单模式采集`: current Creator Center default table/range; not all notes.
- `近 X 天数据`: explicit date range or default recent range visible in Creator Center.
- `选定范围导出`: user-selected filters/date range from exported data.
- `全量导出数据`: only when export or pagination confirms every note in scope was collected.

Never label a quick/default table read as complete account history.

Use Xiaohongshu red (`#ff2442`) as the primary report color. Use warm red/pink backgrounds and red-to-gold accents for bars, scatter points, hero areas, and key values unless the user specifies another brand palette.

## Chart Selection

- Use a sorted bar chart for top CES and top CTR.
- Use a scatter plot for CTR vs CES because it separates packaging strength from content conversion.
- Use a quadrant table when the user needs actionability more than statistical detail.
- Use trend lines by publish date only when there are enough notes across time to avoid overreading noise.
- Use rate charts (`CES/1k exposure`, `save_rate`, `follow_rate`) when exposure varies greatly across notes.

## Client-Facing Writing Rules

- Start with the conclusion, not the method.
- Use concrete note examples for every major claim.
- Label visual judgments as visual judgments when inspecting covers manually.
- Avoid saying a cover/title "caused" performance from observational data. Use "associated with", "appears to", or "worth testing".
- Translate metrics into action: what to repeat, what to revise, what to stop, what to test next.

## Script Usage

Use the bundled script for exported or collected CSV data:

```bash
python scripts/render_ces_report.py input.csv --output outputs/ces_report.html --title "小红书内容表现可视化报告" --profile-json profile.json --coverage-label "默认简单模式采集" --coverage-note "当前数据来自创作者中心默认视图，不代表账号历史全部笔记。"
```

The script expects common Creator Center fields such as `笔记基础信息`, `标题`, `发布日期`, `曝光`, `观看`, `封面点击率`, `点赞`, `评论`, `收藏`, `涨粉`, `分享`, and `note_id`. It also accepts English aliases such as `title`, `date`, `exposure`, `watch`, `ctr`, `likes`, `comments`, `saves`, `follows`, `shares`, and `note_id`.

Optional `profile.json` fields: `display_name`, `handle`, `bio`, `following`, `followers`, `likes_and_saves`, `location`, `role`, and `avatar`/`avatar_url`. Use public profile or Creator Center profile information when available. Use an avatar only when a real image URL or local image file is available; otherwise omit the avatar area instead of rendering initials or a fake placeholder. Do not invent account facts.

When using exported Excel files, convert them to CSV first with the spreadsheets skill or a local parser, then run the script.
