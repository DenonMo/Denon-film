# Style References

Use this reference when suggesting visual directions, photographers, or reference-image keywords.

## Match References To Intent

Do not name photographers as decoration. Connect each reference to a usable shooting behavior:

- What to look for.
- How to compose.
- What light to prefer.
- What film/rendering character fits.

## Reference Directions

Street and grain:

- Daido Moriyama: high contrast, rough grain, strong shadows, instinctive street fragments.
- Garry Winogrand: crowded street rhythm, gesture, tilted energy.

Color travel and ordinary scenes:

- William Eggleston: ordinary objects, saturated color, democratic attention.
- Stephen Shore: road trips, architecture, quiet color structure.

Soft daily life and light:

- Rinko Kawauchi: gentle light, small details, airy color, emotional quietness.
- Hideaki Hamada: family, travel, soft natural light, nostalgic color.

Layered city and atmosphere:

- Saul Leiter: windows, reflection, compression, color patches, rain/snow.
- Fan Ho: geometry, light beams, silhouette, city mood.

Japanese travel/editorial feeling:

- Look for clean composition, understated colors, small human presence, texture, seasonal details.

Night and festival atmosphere:

- Use references around lanterns, stalls, waiting crowds, silhouettes, faces lit by practical light, and warm/cool color contrast.

## Reference Keyword Templates

Use bilingual keywords when helpful:

- `35mm film snow wall blue sky fine grain travel photography`
- `Kodak Vision3 50D seaside travel film photo`
- `Japanese summer festival 500T film night portrait lantern`
- `film photography fireworks festival crowd yukata`
- `胶片 雪墙 蓝天 旅行 摄影`
- `胶片 海边 城市 阴天 旅行`
- `花火大会 胶片 夜景 人像 浴衣 灯笼`

