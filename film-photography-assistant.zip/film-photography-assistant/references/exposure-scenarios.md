# Exposure And Scenario Heuristics

Use this reference for manual film settings, film stock selection, and scene risk.

## Sunny 16 Baseline

Start from:

- Bright sun: f/16, shutter near 1/ISO.
- Normal sun: f/11.
- Light cloud or bright shade: f/8.
- Overcast: f/5.6.
- Deep shade, forest, dusk, indoor window light: f/4 or wider.

Then adjust for:

- User safe shutter range.
- Highest camera shutter speed.
- Desired depth of field.
- Film latitude.
- Known camera issues.

## Film Latitude

- Color negative: prefer slight overexposure to underexposure.
- Vision3 cinema negative: often tolerates and likes mild overexposure; avoid severe underexposure.
- Slide film: expose carefully and protect highlights.
- Black and white negative: flexible; tune for subject contrast.

## Useful Stock Heuristics

- Kodak Vision3 5203 / 50D: bright daylight, snow, seaside, high reflection, blue sky, fine grain, clean travel scenes. Risky in cloudy forest, dusk, night, or handheld low light.
- Kodak Vision3 5207 / 250D: mixed daylight, cloudy travel, seaside with changing light, afternoon, safer all-around choice than 50D when light is uncertain.
- Kodak Vision3 5219 / 500T: night, indoor, fireworks festival atmosphere, street lights, people, handheld evening scenes. Strong practical choice when 800T is too expensive.
- CineStill 800T or similar 800T: night ambience, neon, halation, handheld event atmosphere. Not always ideal for pure fireworks trails.
- Kodak Gold 200: casual daylight, warm travel, affordable everyday scenes.
- Portra 400/800: portrait, skin tone, mixed light, flexible travel.
- Ektar 100: vivid color, daylight landscape, careful exposure.

## Scenario Rules

Snow or high mountain daylight:

- Favor low ISO if the camera max shutter is limited.
- Warn that snow fools meters into gray; suggest +1EV or metering around ISO 32 for ISO 50 when appropriate.
- Preserve highlight detail but do not underexpose color negative too much.

Seaside daylight:

- Expect strong reflection and fast-changing cloud cover.
- 50D is excellent in hard sun; 250D is more forgiving if weather changes.
- Watch max shutter limits when using 250D or faster film.

Night handheld:

- Prioritize enough ISO over perfect color temperature.
- Treat anything below the user's handheld safe shutter as risky unless blur is desired.
- Suggest 500T/800T, flash, support, or a faster lens.

Fireworks:

- Pure fireworks trails: low ISO, tripod/fixed support, B mode or long exposure, f/8-f/16, roughly 2-10 seconds depending on density.
- Fireworks festival atmosphere: 500T/800T for people, stalls, lanterns, waiting crowds, faces lit by fireworks.
- Handheld fireworks trails on film are high risk; suggest digital/phone backup for the trails if needed.

Old camera with 1/500 max:

- Low ISO film is useful in bright scenes.
- 250D may hit the shutter ceiling in snow, beach, or high noon if the user wants wider apertures.
- Offer stopping down, ND filter, lower ISO film, or accepting a smaller aperture.

