# Equipment Risk

Use this reference when the user gives a film camera model, old camera condition, known fault, or handling uncertainty.

## Research Process

When a model is named:

1. Search the web for common issues, repair notes, user reports, and operation manuals.
2. Prefer repair shops, manuals, forum threads with repeated reports, and long-term owner notes.
3. Separate confirmed user issues from model-wide risks.
4. Do not claim the user's copy has a defect unless the user reported or tested it.
5. Translate risks into shoot behavior: what to avoid, how to test, and what backup settings to use.

## Hard Constraints

User-reported issues are hard constraints. Examples:

- If 1/500 is unreliable, avoid exposure plans that require 1/500.
- If the meter is inaccurate, do not rely on in-camera meter-only advice.
- If the rangefinder is misaligned, avoid shallow depth-of-field close portraits unless stopped down or refocused by scale.
- If film advance spacing is uneven, warn against irreplaceable one-shot moments and suggest checking transport before the trip.
- If light seals leak, avoid strong backlight or tape the back as a precaution.

## Common Old-Camera Risks

Treat these as caution flags:

- Mechanical shutter speeds can drift, especially slow speeds.
- Cloth shutters can show pinholes, capping, or uneven travel.
- Electronic cameras may depend on batteries and clean contacts.
- Selenium meters may be weak or dead.
- Foam light seals and mirror dampers often degrade.
- Rangefinders can be vertically or horizontally misaligned.
- Old leaf shutters may stick at slow speeds.
- Film counters, rewind buttons, or take-up spools may fail under tension.

## Safer Advice Patterns

- Keep one stop of exposure margin when possible.
- Avoid critical shots at the camera's most suspicious speed.
- Prefer mid-range shutter speeds when mechanical reliability is unknown.
- Use external metering or a phone meter when the in-camera meter is questionable.
- Suggest a blank-roll or no-film function test before important travel.
- For once-in-a-trip scenes, bracket when film stock and scene permit.

