# Xiaohongshu Publishing

Use this reference after account analysis or when giving Xiaohongshu-oriented shooting and caption advice.

## Privacy

Never embed account IDs, test accounts, profile URLs, Creator Center exports, or historical metrics in this skill. Use only runtime data provided or authorized by the user.

## CES Interpretation

If using `$xiaohongshu-ces-analysis`, interpret:

- High CTR: cover/title/topic earns clicks.
- High CES: the note creates stronger engagement.
- High CTR but weak CES: good packaging, weaker content payoff.
- Moderate CTR but strong CES: content resonates, packaging may need improvement.
- High saves: useful routes, settings, lists, reference value.
- High comments: opinions, prompts, personal story, relatable questions.
- High shares: practical guides, beautiful place, repeatable template.
- High follows: clear creator positioning or series value.

## Turn Analysis Into Shoot Advice

Translate performance patterns into decisions:

- If travel guides perform: shoot route signs, maps, transport, before/after, practical details.
- If film gear posts perform: include camera-in-hand, film boxes, meter/settings notes.
- If people improve engagement: plan one human anchor in the first three images.
- If pure scenery underperforms: add narrative, scale, route, or equipment context.
- If night atmosphere performs: prioritize people under signs, lanterns, windows, stalls, and mixed color light.

## Cover And First Three Images

Recommend:

- Cover: one clear subject, readable mood, high contrast or recognizable place.
- Image 2: context or route.
- Image 3: detail, person, or equipment hook.

Avoid making all first three images similar empty landscapes unless the account data proves that works.

## Caption Structure

Use:

1. One-sentence hook.
2. Scene or route context.
3. Film/camera/settings when relevant.
4. Practical shooting note.
5. Small personal observation.
6. Question or save-worthy list.

## Title Patterns

Adapt to account findings. Useful starting forms:

- `用一卷胶片记录...`
- `这组照片让我觉得...`
- `如果去...我会这样带胶卷`
- `胶片机拍...到底怎么设`
- `...天气下，我更推荐这卷`

Do not overpromise. Keep titles concrete and aligned with the photos.
